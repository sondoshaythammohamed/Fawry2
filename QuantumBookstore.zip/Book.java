public abstract class Book {
    protected String isbn;
    protected String title;
    protected int yearPublished;
    protected double price;
    protected String author;

    public Book(String isbn, String title, int year, double price, String author) {
        this.isbn = isbn;
        this.title = title;
        this.yearPublished = year;
        this.price = price;
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public abstract void buy(int quantity, String email, String address);
}