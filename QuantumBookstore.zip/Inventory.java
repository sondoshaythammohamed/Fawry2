import java.util.*;

public class Inventory {
    private Map<String, Book> books = new HashMap<>();

    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
        System.out.println("Quantum book store: Added book: " + book.title);
    }

    public Book removeBook(String isbn) {
        return books.remove(isbn);
    }

    public void buyBook(String isbn, int quantity, String email, String address) {
        Book book = books.get(isbn);
        if (book == null) {
            throw new RuntimeException("Quantum book store: Book not found with ISBN " + isbn);
        }
        book.buy(quantity, email, address);
    }

    public List<Book> removeOutdatedBooks(int maxYearsOld) {
        List<Book> removed = new ArrayList<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        Iterator<Map.Entry<String, Book>> iterator = books.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, Book> entry = iterator.next();
            if (currentYear - entry.getValue().getYearPublished() > maxYearsOld) {
                removed.add(entry.getValue());
                System.out.println("Quantum book store: Removing outdated book: " + entry.getValue().title);
                iterator.remove();
            }
        }
        return removed;
    }
}